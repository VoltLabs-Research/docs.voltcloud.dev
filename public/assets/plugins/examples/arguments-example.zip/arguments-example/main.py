import sys

print('sys.argv:')
for idx, arg in enumerate(sys.argv):
    print(idx, arg)
